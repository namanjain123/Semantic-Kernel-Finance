export const setSelectedId = (id) => ({
  type: 'SET_SELECTED_ID',
  payload: { message: "Hello from GeeksforGeeks!", id: id },
});
